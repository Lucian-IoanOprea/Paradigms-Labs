import Data.List
import Data.Word
import Data.Bits
import Data.Char
import System.Random hiding (randoms)


square x = x * x
square2 x = (*) x x
myx x = x + 100